/*Following code has been developed for Cryptography Course, the code could be optimized in many ways, but in order to keep the readability performance might have been dissmissed.*/
/*After all this is not a programming course.*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

const char SUB_TBL[2][26] = {{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'},
                            {'U','K','G','V','P','I','Y','C','L','W','M','T','F','O','R','N','H','D','Z','Q','B','E','S','X','A','J'}};
typedef struct {
    char *ptxt;
    char *ctxt;
    unsigned int size;
}stu_cipher;
void print_cipher(stu_cipher _c) {
    printf("sizeoftext: %d\n",_c.size);
    printf("plain text: %s\n",_c.ptxt);
    printf("crypt text: %s\n\n",_c.ctxt);
}
unsigned int find_coresp_char_index (bool _encrypt, const char _c)
{
   unsigned int index,tbl =0;
   if(_encrypt)
       tbl=0;
   else
       tbl=1;
   for (index = 0;index<26;++index)
       if(SUB_TBL[tbl][index] == _c)
           break;
   return index;
}
stu_cipher encrypt(stu_cipher _c) {
    _c.ctxt = (char *)malloc(_c.size+1);
    int i;
    for (i = 0; i < _c.size; ++i)
    {        
        unsigned int j = find_coresp_char_index(true,_c.ptxt[i]);
        _c.ctxt[i] = SUB_TBL[1][j];
    }
    _c.ctxt[_c.size] ='\0';
    print_cipher(_c);    
    free(_c.ctxt);
}
stu_cipher decrypt(stu_cipher _c) {    
    _c.ptxt = (char *)malloc(_c.size+1);
    int i;
    for (i = 0; i < _c.size; ++i)
    {        
        unsigned int j = find_coresp_char_index(false,_c.ctxt[i]);
        _c.ptxt[i] = SUB_TBL[0][j];
    }
    _c.ptxt[_c.size] = 0x00;
    print_cipher(_c);
    free(_c.ptxt);    
}
unsigned int getSize(const char *_txt)
{
    unsigned int size;
    for (size = 0;_txt[size];_txt[size]=='\0'?:++size);
    return size;
}
int main(int argc, char *argv[]) {
    if (argc != 3)
    {
         printf("USAGE: -d file.txt TO DECRYPT OR -e file.txt TO ENCRYPT.\n");
         return 0;
    }
    bool enc;
    if (!strncmp(argv[1], "-e", 2))
            enc = true;
    else if (!strncmp(argv[1], "-d", 2))
            enc = false;
    else
    {
        printf("USAGE: -d file.txt TO DECRYPT OR -e file.txt TO ENCRYPT.\n");
        return 0;
    }

    FILE *fp;
    fp=fopen(argv[2], "r");
    if (fp == NULL)
        return 0;
    fseek(fp, 0L, SEEK_END);
    int size = ftell(fp);
    rewind(fp);
    char *f = (char *)malloc(size);
    int i = 0;
    while (i<size) {
        fscanf(fp,"%s",f);
        stu_cipher s;
        s.size = getSize(f);
        i+=s.size;
        if (!s.size)
        {
            ++i;
            continue;
        }
        if (enc)
        {
            s.ptxt = f;
            encrypt(s);
        }
        else
        {
            s.ctxt = f;        
            decrypt(s);
        }

    }
    free(f);
    fclose(fp);
    return 0;
}
