/*Following code has been developed for Cryptography Course, the code could be optimized in many ways, but in order to keep the readability performance might have been dissmissed.*/
/*After all this is not a programming course.*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <klee/klee.h>


const char SUB_TBL[2][26] = {{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'},
                            {'U','K','G','V','P','I','Y','C','L','W','M','T','F','O','R','N','H','D','Z','Q','B','E','S','X','A','J'}};
typedef struct {
    char *ptxt;
    char *ctxt;
    unsigned int size;
}stu_cipher;
void print_cipher(stu_cipher _c) {
    printf("sizeoftext: %d\n",_c.size);
    printf("plain text: %s\n",_c.ptxt);
    printf("crypt text: %s\n\n",_c.ctxt);
}
unsigned int find_coresp_char_index (bool _encrypt, const char _c)
{
   unsigned int index,tbl =0;
   if(_encrypt)
       tbl=0;
   else
       tbl=1;
   for (index = 0;index<26;++index)
       if(SUB_TBL[tbl][index] == _c)
           break;
   return index;
}
stu_cipher encrypt(stu_cipher _c) {
    _c.ctxt = (char *)malloc(_c.size+1);    
    int i;
    for (i = 0; i < _c.size; ++i)
    {        
        unsigned int j = find_coresp_char_index(true,_c.ptxt[i]);
        _c.ctxt[i] = SUB_TBL[1][j];
    }
    _c.ctxt[_c.size] ='\0';
    print_cipher(_c);
    free(_c.ctxt);
}
stu_cipher decrypt(stu_cipher _c) {    
    _c.ptxt = (char *)malloc(_c.size+1);
    int i;
    for (i = 0; i < _c.size; ++i)
    {        
        unsigned int j = find_coresp_char_index(false,_c.ctxt[i]);
        _c.ptxt[i] = SUB_TBL[0][j];
    }
    _c.ptxt[_c.size] ='\0';
    print_cipher(_c);
    free(_c.ptxt);
}
unsigned int getSize(const char *_txt)
{
    unsigned int size;
    for (size = 0;_txt[size];_txt[size]=='\0'?:++size);
    return size;
}
//#define SIZE 1024
#define SIZE 8
int main(int argc, char *argv[]) {
    // The input regular expression.
    char cipher_txt[SIZE];
    char plain_txt[SIZE];

    // Make the input symbolic.
    klee_make_symbolic(cipher_txt, sizeof cipher_txt, "cipher_txt");
    klee_make_symbolic(plain_txt, sizeof plain_txt, "plain_txt");

    stu_cipher e;
    e.ptxt = plain_txt;
    e.size = strlen(e.ptxt);
    if (!e.size)
        encrypt(e);

    stu_cipher d;
    d.ctxt = cipher_txt;
    d.size = strlen(d.ctxt);
    if (!d.size)
        decrypt(d);


    return 0;
}
