#!/bin/sh
argc=$#
if [ $argc -ne 2 ]; then
        echo "Provide the path to the .c file you want to compile and the path to KLEE output."
        exit 0;
fi
AFL_LIB=/home/klee/klee_build/klee/lib/
AFL_INC=/home/klee/klee_src/include
export LD_LIBRARY_PATH=$AFL_LIB:$LD_LIBRARY_PATH
gcc -L $AFL_LIB -I $AFL_INC -o $1.bin $1 -lkleeRuntest
