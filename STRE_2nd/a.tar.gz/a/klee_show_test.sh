#!/bin/sh
argc=$#
if [ $argc -eq 0 ]; then
        echo "Provide the path to klee output."
        exit 0;
fi

for i in `find $1 -name '*.ktest'`;
do
       ktest-tool --write-ints $i
done
