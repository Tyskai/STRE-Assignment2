#!/bin/sh

KLEE_INC=/home/klee/klee_src/include
clang -I $KLEE_INC -emit-llvm -c -g  a_klee.c
clang -I $KLEE_INC -emit-llvm -c -g  a_klee_fixed.c
clang -I $KLEE_INC -emit-llvm -c -g  a_klee_fixed_2.c

