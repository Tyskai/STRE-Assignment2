#!/bin/sh
docker run --rm -ti  -v `pwd`:/home/klee/a --ulimit='stack=-1:-1' klee/klee
