#!/bin/sh
argc=$#
if [ $argc -eq 0 ]; then
        echo "Provide the name of the binary."
	exit 0;
fi
BIN=$1
FAILE_TESTS=0
PASSE_TESTS=0
echo -e "\e[1mTesting Crashes For Encryption With $BIN.\n"
for i in `find ./findings/output/crashes -name '*sig*src*'`;
do
        echo -e "\e[0mTesting $i."
        $BIN -f $i >> /dev/null;
        if [ $? -eq 0 ]
        then
                echo -e "\e[32mSUCCEEDED"
                let PASSE_TESTS=PASSE_TESTS+1
        else
                echo -e "\e[91mFAILED!!!"
                let FAILE_TESTS=FAILE_TESTS+1
        fi
        echo -e "---------\n"
done

echo -e "\e[0m*************\n** RESULTS **\n*************"
echo -e "\e[32mSUCCEEDED: $PASSE_TESTS"
echo -e "\e[91mFAILED!!!: $FAILE_TESTS"
echo -e "\e[0m---------\n"
